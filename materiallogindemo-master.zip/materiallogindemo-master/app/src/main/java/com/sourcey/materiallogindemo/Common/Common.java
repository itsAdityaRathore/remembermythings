package com.sourcey.materiallogindemo.Common;

import com.sourcey.materiallogindemo.Model.User;

public class Common {
    public static User currentUser;

    public static final String UPDATE = "Update";
    public static final String DELETE = "Delete";

    public static final int PICK_IMAGE_REQUEST = 71;

}
